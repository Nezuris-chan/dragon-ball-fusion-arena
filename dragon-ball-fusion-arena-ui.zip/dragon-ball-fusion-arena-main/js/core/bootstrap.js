
const C=document.getElementById('c'),M=document.getElementById('m'),W=960,GY=440;let X=C.getContext('2d');
const SUPABASE_URL='https://djxbhgqggthruibiccss.supabase.co';
const SUPABASE_PUBLISHABLE_KEY='sb_publishable_oIb75TVKlRuPSSha9uuERQ_LXdulsan';
const sbClient=window.supabase?.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY)||null;
let onlineUser=null;
let sv={xp:0,w:0,l:0};try{const raw=localStorage.getItem('fa');if(raw)sv=Object.assign(sv,JSON.parse(raw));}catch(e){try{const bak=localStorage.getItem('fa_backup');if(bak)sv=Object.assign(sv,JSON.parse(bak));}catch(_){}}
sv._saveVersion=Math.max(1,Number(sv._saveVersion)||1);if(sv._saveVersion<3){sv.xp=0;sv.w=0;sv.l=0;sv.rp=0;sv.story={done:{},fl:{},forms:{}};sv.items=[];sv.equippedItem='';sv.daily={};sv._saveVersion=3;}sv.rp=Math.max(0,Number(sv.rp)||0);
const save=()=>{try{const old=localStorage.getItem('fa');if(old)localStorage.setItem('fa_backup',old);sv.items=Array.isArray(sv.items)?sv.items:[];sv.equippedItem=sv.equippedItem||'';sv._saveVersion=3;localStorage.setItem('fa',JSON.stringify(sv));}catch(e){console.warn('Sauvegarde locale indisponible',e)}if(onlineUser&&sbClient)sbClient.from('profiles').update({xp:Math.max(0,Number(sv.xp)||0),player_level:Math.min(100,1+Math.floor((Math.sqrt(1+8*Math.max(0,Number(sv.xp)||0)/250)-1)/2)),...(sv.pseudo&&sv.pseudo!=='Joueur'&&!String(sv.pseudo).startsWith('Joueur-')?{username:String(sv.pseudo).slice(0,16)}:{})}).eq('id',onlineUser.id).then(({error})=>{if(error)console.warn('Synchronisation du profil impossible',error.message)})};
const RELICS=[
{id:'zenkai',name:'Armure Saiyan',desc:'Réduit les dégâts reçus de 6 %',chapter:'s1c4',damage:1,resist:1.06},
{id:'kai',name:'Sceau du Kaiô',desc:'Augmente les dégâts de 6 %',chapter:'s2c3',damage:1.06,resist:1},
{id:'god',name:'Insigne divin',desc:'Bonus équilibré : +3,5 % dégâts et résistance',chapter:'film2',damage:1.035,resist:1.035},
{id:'potara',name:'Boucles Potara',desc:'+8 % dégâts, mais -2 % résistance',price:180,damage:1.08,resist:.98},
{id:'scouter',name:'Scouter perfectionné',desc:'+6 % dégâts et +3 % résistance',price:160,damage:1.06,resist:1.03},
{id:'senzu',name:'Haricot magique',desc:'+10 % résistance, +2 % dégâts',price:200,damage:1.02,resist:1.10},
{id:'angel',name:'Bâton angélique',desc:'+5 % dégâts et +8 % résistance',price:260,damage:1.05,resist:1.08},
{id:'destroyer',name:'Symbole du Dieu de la destruction',desc:'+12 % dégâts, mais -5 % résistance',price:320,damage:1.12,resist:.95},
{id:'dragon',name:'Éclat de Dragon Ball',desc:'+7 % dégâts et +7 % résistance',price:280,damage:1.07,resist:1.07}
];
sv.items=Array.isArray(sv.items)?sv.items:[];sv.equippedItem=sv.equippedItem||'';
const equippedRelic=()=>RELICS.find(x=>x.id===sv.equippedItem&&sv.items.includes(x.id))||null;
const dailyDate=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const DAILY_QUESTS=[{id:'play2',name:'Combattant régulier',desc:'Terminer 2 combats',key:'played',goal:2,xp:60,rp:10},{id:'win1',name:'Vainqueur du jour',desc:'Remporter 1 combat',key:'wins',goal:1,xp:80,rp:20},{id:'story1',name:'Héros de la saga',desc:'Gagner 1 combat en mode Histoire',key:'storyWins',goal:1,xp:100,rp:25}];
function ensureDaily(){if(!sv.daily||sv.daily.date!==dailyDate())sv.daily={date:dailyDate(),played:0,wins:0,storyWins:0,claimed:[]};sv.daily.played=Math.max(0,Number(sv.daily.played)||0);sv.daily.wins=Math.max(0,Number(sv.daily.wins)||0);sv.daily.storyWins=Math.max(0,Number(sv.daily.storyWins)||0);if(!Array.isArray(sv.daily.claimed))sv.daily.claimed=[];return sv.daily}
function recordDailyBattle(won,story){const d=ensureDaily();d.played++;if(won){d.wins++;if(story)d.storyWins++}const rewards=[];for(const q of DAILY_QUESTS){if(d[q.key]>=q.goal&&!d.claimed.includes(q.id)){d.claimed.push(q.id);sv.xp+=q.xp;sv.rp=(sv.rp||0)+q.rp;rewards.push(q.name+' : +'+q.xp+' XP, +'+q.rp+' points')}}save();if(rewards.length)G.ann={t:220,s:'QUÊTE(S) TERMINÉE(S) !',c:'#fd6',big:true};return rewards}
function dailyMenu(){const d=ensureDaily();M.style.display='flex';M.style.background='';M.innerHTML='<h1>QUÊTES QUOTIDIENNES</h1><small>Réinitialisation chaque jour · Récompenses ajoutées automatiquement à ta progression</small>';for(const q of DAILY_QUESTS){const n=Math.min(q.goal,d[q.key]),done=d.claimed.includes(q.id),el=mk('div');el.style.cssText='width:min(90%,520px);text-align:left;padding:10px 14px;margin:5px;background:#101a30;border:1px solid '+(done?'#4c8':'#357')+';border-radius:8px';el.innerHTML='<b>'+q.name+'</b> '+(done?'✓ RÉCLAMÉ':'')+'<br><small>'+q.desc+'</small><div style="height:8px;background:#26344b;margin:8px 0;border-radius:8px;overflow:hidden"><div style="height:100%;width:'+(n/q.goal*100)+'%;background:linear-gradient(90deg,#08c,#6ef)"></div></div><small>'+n+' / '+q.goal+' · Récompense : '+q.xp+' XP + '+q.rp+' points de classement</small>';M.appendChild(el)}M.appendChild(mk('small','Progression du jour : '+d.claimed.length+' / '+DAILY_QUESTS.length+' quêtes terminées'));M.appendChild(btn('← Retour',menu))}

const al=(h,a)=>{h=h.replace('#','');if(h.length==3)h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];return 'rgba('+parseInt(h.slice(0,2),16)+','+parseInt(h.slice(2,4),16)+','+parseInt(h.slice(4,6),16)+','+a+')'};
