// ---- Attaques par personnage, SSJ3, formes chronométrées ----
HS.ssj3=[[16,-100],[26,-112],[18,-120],[28,-136],[12,-132],[16,-150],[2,-138],[-4,-160],[-12,-138],[-24,-154],[-24,-130],[-38,-138],[-32,-116],[-46,-110],[-38,-92],[-50,-76],[-36,-72],[-44,-46],[-30,-50],[-36,-22],[-20,-44],[-22,-66],[-14,-82],[-14,-92],[-8,-100],[0,-104],[8,-100]];
const mv=(n,d,k,f,T,sh,c,c2,w,spd,l,imp)=>({n,d,k,f,T,sh,c,c2,w,spd,l,imp});
const BB=mv('Big Bang Attack',16,22,14,26,'bigbang','#fe4','#fff',26,14,90,90);
const MVS={Goku:[mv('Kamehameha',18,25,16,32,'kamehameha','#4cf','#fff',24,12,70,110),Object.assign(mv('Dragon Fist',22,30,10,30,'dragon','#fa3','#fff',26,15,32,100),{dash:1}),Object.assign(mv('Genkidama',60,100,50,92,'genki','#9cf','#fff',90,9,110,260),{st:'arc',up:1})],Vegeta:[mv('Galick Gun',20,28,18,34,'galick','#c6f','#fff',24,12,70,110),BB,mv('Final Flash',52,90,34,68,'flash','#fe4','#fff',46,17,70,240)],Gogeta:[mv('Soul Punisher',20,25,16,30,'ball','#c9f','#fff',32,10,100,100),mv('Big Bang Kamehameha',24,32,18,36,'beam','#4cf','#fd4',28,13,70,130),Object.assign(mv('Stardust Breaker',58,100,44,84,'stardust','#fff','#fff',80,10,90,260),{st:'arc',up:1}),Object.assign(mv('Punisher Drive',8,25,8,30,'rush','#fd4','#fff',30,14,24,60),{dash:1,mh:4})],Vegetto:[mv('Spirit Sword',19,24,12,28,'sword','#6df','#fff',24,16,14,90),BB,mv('Final Kamehameha',55,95,36,74,'fusion','#7cf','#fe4',46,16,70,250)],Broly:[mv('Eraser Cannon',22,28,18,32,'ball','#7f5','#fff',36,11,100,110),mv('Gigantic Roar',24,30,16,34,'wave','#9f5','#fff',50,10,60,130),Object.assign(mv('Gigantic Meteor',62,100,46,86,'meteor','#5f3','#af6',80,11,90,260),{st:'arc',up:1}),Object.assign(mv('Gigantic Charge',40,30,12,34,'charge','#7f5','#fff',40,16,22,140),{dash:1})],'Gohan':[mv('Light Cannon',19,25,16,30,'ball','#dcf','#fff',30,12,100,100),mv('Makankosappo',26,35,20,38,'spiral','#c6f','#fd4',16,18,50,120),mv('Beast Kamehameha',56,95,34,70,'beastk','#fff','#a6f',44,16,70,250)],Freezer:[mv('Death Beam',17,20,10,22,'thin','#f6c','#fff',16,22,50,80),mv('Death Ball',26,34,24,46,'sphere','#c6f','#fff',55,6,110,170),Object.assign(mv('Supernova',60,100,50,90,'nova','#f8c','#fff',105,16,80,280),{st:'drop',up:1,trk:1}),mv('Death Saucer',24,30,18,34,'saucer','#f6c','#fff',36,14,80,110)]};
Object.assign(MVS,{Trunks:[mv('Burning Attack',20,26,16,32,'ball','#fd4','#fff',34,13,100,110),Object.assign(mv('Sword Slash',22,24,8,26,'sword','#cfe','#fff',24,16,12,90),{dash:1}),mv('Finish Buster',55,95,34,70,'buster','#fd4','#fff',42,16,70,240)],Piccolo:[mv('Masenko',19,25,14,28,'beam','#fd4','#fff',22,14,70,100),mv('Hellzone Grenade',24,32,20,38,'multi','#6f6','#fff',60,8,100,130),mv('Special Beam Cannon',56,95,34,70,'spiral','#fd4','#fa4',28,19,50,230)],Cell:[mv('Kamehameha',19,26,18,34,'beam','#4cf','#fff',28,12,70,110),mv('Solar Kamehameha',27,34,20,38,'beam','#fe4','#fff',36,14,70,150),mv('Perfect Kamehameha',58,100,38,78,'ringbeam','#6f4','#cfc',50,16,70,260)],Beerus:[mv('Hakai Sphere',22,26,14,28,'ball','#b4f','#fff',34,12,100,120),mv('Destruction Wave',26,32,16,32,'wave','#c6f','#fff',54,10,60,140),mv('Sphere of Destruction',60,100,44,86,'hakai','#a2f','#d8f',95,6,120,270)],Jiren:[mv('Power Impact',22,26,16,30,'ball','#f55','#fff',38,12,100,120),mv('Burning Beam',27,34,22,40,'beam','#f66','#fff',34,14,70,140),Object.assign(mv('Impact ultime',62,100,22,70,'impact','#f44','#fff',70,18,38,280),{dash:1})]});
Object.assign(MVS,{Gotenks:[mv('Die Die Missile Barrage',16,22,14,26,'multi','#f8f','#fff',60,10,90,90),mv('Galactic Donuts',24,30,18,34,'wave','#fc4','#fff',46,10,70,120),mv('Super Ghost Kamikaze Attack',56,95,36,76,'ghosts','#c8f','#fff',70,9,100,240)],'Majin Buu':[mv('Candy Beam',18,24,14,28,'beam','#fbd','#fff',22,13,70,100),mv('Vanishing Ball',26,32,20,36,'ball','#f9b','#fff',44,10,100,130),Object.assign(mv('Planet Burst',60,100,50,90,'planet','#f9d','#fff',95,9,100,275),{st:'arc',up:1})],Hit:[mv('Flash Fist',18,22,8,22,'thin','#c8f','#fff',16,24,40,80),Object.assign(mv('Time Skip',21,26,6,26,'rush','#a6f','#fff',30,16,24,80),{dash:1,mh:3}),Object.assign(mv('Pure Progress',58,100,16,62,'cuts','#a6f','#fff',60,0,40,230),{st:'pillar',wt:8})],'Goku Black':[Object.assign(mv('Divine Blade',21,26,10,28,'sword','#f6c','#fff',26,16,14,100),{dash:1}),mv('Dark Kamehameha',24,30,18,34,'beam','#b2f','#fff',28,13,70,130),mv('Judgment Flash',58,100,34,72,'scythe','#f5c','#fff',70,17,60,240)],Cooler:[mv('Death Flash',18,22,10,22,'thin','#8cf','#fff',16,22,50,80),Object.assign(mv('Nova Chariot',26,30,12,34,'charge','#8cf','#fff',40,16,22,140),{dash:1}),Object.assign(mv('Supernova Cooler',60,100,50,90,'rain','#7af','#fff',100,16,80,280),{st:'drop',up:1,trk:1})],Bardock:[mv('Riot Javelin',20,26,16,30,'ball','#f88','#fff',34,14,100,110),mv('Spirit Breaking Cannon',25,32,18,36,'beam','#f66','#fff',30,13,70,130),mv('Final Spirit Cannon',58,100,38,78,'fireball','#fa4','#fff',80,12,110,265)]});
Object.assign(MVS,{Raditz:[mv('Double Sunday',18,24,14,28,'ball','#fd4','#fff',32,13,100,100),Object.assign(mv('Saturday Crush',20,26,8,26,'charge','#c8f','#fff',34,16,22,110),{dash:1}),Object.assign(mv('Rafale du Saiyan',52,90,30,66,'rush','#c8f','#fff',34,15,44,200),{dash:1,mh:5})],Nappa:[mv('Bomber DX',20,26,18,32,'ball','#f94','#fff',42,10,100,120),mv('Cannon Nappa',24,30,16,32,'wave','#fa6','#fff',50,10,60,130),Object.assign(mv('Volcano Explosion',60,100,40,80,'volcano','#f84','#fff',110,0,50,280),{st:'pillar',wt:30})]});
Object.assign(MVS,{Ginyu:[mv('Milky Cannon',18,24,14,28,'beam','#f8a','#fff',22,13,70,100),mv('Pose Ginyu',24,30,16,32,'multi','#fc6','#fff',58,9,90,120),Object.assign(mv('Galactic Rush',54,92,28,64,'rush','#f8a','#fff',34,15,44,200),{dash:1,mh:5})]});
Object.assign(MVS,{
 'Baby Vegeta':[mv('Revenge Death Ball',24,30,18,34,'sphere','#9cf','#fff',44,11,100,130),mv('Final Flash Revenge',30,38,22,42,'flash','#9cf','#fff',42,15,70,160),Object.assign(mv('Revenge Death Ball géante',60,100,46,86,'nova','#9cf','#fff',92,10,100,270),{st:'arc',up:1})],
 'Omega Shenron':[mv('Dragon Thunder',22,28,16,32,'beam','#f44','#fff',36,13,80,120),mv('Negative Karma Ball',30,38,22,42,'sphere','#b22','#f88',52,10,100,160),Object.assign(mv('Minus Energy Power Ball',64,100,48,90,'planet','#f22','#fff',100,8,120,290),{st:'arc',up:1})],
 Cumber:[mv('Evil Aura Cannon',22,28,18,34,'beam','#c22','#fff',36,12,80,120),mv('Saiyan Rampage',30,36,12,38,'rush','#e22','#fff',42,15,50,150),Object.assign(mv('Evil Saiyan Meteor',62,100,42,84,'meteor','#b11','#f66',90,11,100,280),{st:'arc',up:1})],
 Hearts:[mv('Gravity Fist',20,26,14,30,'impact','#f8a','#fff',32,13,70,110),mv('God Meteor',28,36,20,40,'meteor','#f6a','#fff',48,12,100,150),Object.assign(mv('Universe Seed',60,100,40,80,'planet','#f8a','#fff',88,10,100,270),{st:'arc',up:1})],
 Glorio:[mv('Demon Ray',18,24,12,26,'thin','#9cf','#fff',20,18,50,90),mv('Magic Shot',22,28,18,32,'multi','#9cf','#fff',40,12,80,120),Object.assign(mv('Demon Storm',52,90,30,66,'rain','#9cf','#fff',62,13,80,220),{st:'arc',up:1})],
 Gomah:[mv('Demon Flame',18,24,14,28,'fireball','#f66','#fff',32,12,90,100),mv('Dark Magic',24,30,18,34,'wave','#f44','#fff',44,10,70,130),Object.assign(mv('Demon King Burst',56,95,38,76,'volcano','#f44','#fff',82,0,70,250),{st:'pillar',wt:24})],
 Tamagami:[mv('Guardian Strike',20,26,10,26,'rush','#fd8','#fff',30,15,35,100),mv('Sacred Beam',24,30,16,32,'beam','#fd8','#fff',30,13,70,130),Object.assign(mv('Dragon Ball Seal',56,95,36,72,'ringbeam','#fd8','#fff',58,14,70,240),{st:'pillar',wt:18})],
 'Xeno Goku':[mv('Xeno Kamehameha',20,26,16,32,'kamehameha','#f66','#fff',28,13,70,110),mv('Time Patrol Rush',26,32,10,34,'rush','#f66','#fff',36,16,38,130),Object.assign(mv('Super Dragon Fist',58,100,36,78,'dragon','#f44','#fff',66,15,42,260),{dash:1})],
 Shallot:[mv('Wild Cannon',19,25,14,30,'beam','#f84','#fff',26,13,70,100),mv('Rising Rush',24,30,10,32,'rush','#f84','#fff',34,16,36,120),Object.assign(mv('Godly Warrior Strike',56,95,34,72,'dragon','#f44','#fff',56,15,40,240),{dash:1})]
});
// Coups signature pour les deux personnages qui n'avaient pas encore de jeu de mouvements.
MVS['Android 13']=[mv('S.S. Deadly Bomber',20,26,14,30,'sphere','#8cf','#fff',34,12,90,110),mv('Energy Crush',24,30,16,34,'rush','#8cf','#fff',38,14,40,130),mv('Full Power Energy Ball',58,96,38,78,'nova','#8cf','#fff',82,11,90,250)];
MVS.Tapion=[mv('Brave Sword Attack',18,24,8,26,'sword','#f88','#fff',24,16,18,90),mv('Brave Cannon',24,30,16,34,'beam','#f88','#fff',30,13,70,130),mv('Hirudegarn Seal',54,92,34,70,'wave','#f88','#fff',60,12,80,240)];
const MV=(f,i)=>{const list=MVS[f.c.n]||MVS.Goku;return list[Math.max(0,Math.min(list.length-1,i|0))]},mc=(f,i)=>Math.max(5,Math.min(100,Math.round(MV(f,i).k*(1-f.f$.kr)*(f.c.kiCostMult||1))));
function fireMv(f){const m=f.mv;if(!m){f.st='i';return}const st=f.c.st||{},rate=Math.max(.68,Math.min(1.38,1+(st.te-50)*.0035+(st.en-50)*.0018+(st.in-50)*.0017)),launch=Math.max(4,Math.round(m.f/rate)),finish=Math.max(launch+8,Math.round(m.T/rate));if(f.t>=launch&&!f.mvFired){f.mvFired=1;const o2=f===G.a?G.b:G.a,sc=f.f$.sc*(f.c.lk.sc||1);let x=f.x+f.face*(m.sh==='sword'?70:40),y=f.y-70,vx=f.face*m.spd,vy=0,wait=0;if(m.st==='drop'){x=o2.x;y=-80;vx=0;vy=m.spd}else if(m.st==='pillar'){x=o2.x;y=o2.y-60;vx=0;wait=m.wt||22}else if(m.st==='arc'){y=f.y-150*sc;vy=(o2.y-60-y)/Math.max(1,Math.abs(o2.x-x)/m.spd)}G.pr.push({x,y,vx,vy,wait,o:f,l:m.l,d:m.d,ul:f.at==='ul'?1:0,m});G.ann={t:80,s:m.n,c:m.c,big:f.at==='ul'};sfxMv(m);shake=Math.max(shake,f.at==='ul'?18:6)}if(f.t>finish){f.st='i';f.at=null;f.mv=null;f.atk=null;f.mvFired=0}}
function drawPj(p){const m=p.m,c=m.c,c2=m.c2||'#fff',d=p.o.face,t=G.tick,w=m.w,x=p.x,y=p.y,sh=m.sh;
 // Rendu léger des projectiles : évite les dizaines de dégradés et de tracés coûteux par image.
 if(true){X.save();X.globalCompositeOperation='lighter';const beam=['beam','thin','spiral','kamehameha','galick','flash','fusion','beastk','buster','ringbeam','buster','buster','fireball'].includes(sh);
 if(beam){const len=['thin'].includes(sh)?145:220,thick=Math.max(5,Math.min(34,w*.55));X.globalAlpha=.22;X.fillStyle=c;X.fillRect(Math.min(x,x-d*len),y-thick*1.8,len,thick*3.6);X.globalAlpha=.85;X.fillStyle=c;X.fillRect(Math.min(x,x-d*len),y-thick,len,thick*2);X.globalAlpha=1;X.fillStyle=c2;X.fillRect(Math.min(x,x-d*len),y-thick*.28,len,thick*.56)}
 else{const radius=Math.max(9,Math.min(38,w*.58));X.globalAlpha=.2;X.fillStyle=c;X.beginPath();X.arc(x,y,radius*1.8,0,6.28);X.fill();X.globalAlpha=.9;X.fillStyle=c;X.beginPath();X.arc(x,y,radius,0,6.28);X.fill();X.fillStyle=c2;X.beginPath();X.arc(x,y,radius*.42,0,6.28);X.fill()}
 X.restore();return}
 X.save();X.globalCompositeOperation='lighter';const glow=(r,col)=>{const g=X.createRadialGradient(x,y,2,x,y,r);g.addColorStop(0,'#fff');g.addColorStop(.4,al(col,.9));g.addColorStop(1,al(col,0));X.fillStyle=g;X.beginPath();X.arc(x,y,r,0,6.28);X.fill()},bar=(L,ww,cols)=>{for(const [k,col] of cols){X.fillStyle=col;X.beginPath();X.moveTo(x,y-ww*k);X.lineTo(x-d*L,y-ww*k*.7);X.lineTo(x-d*L,y+ww*k*.7);X.lineTo(x,y+ww*k);X.closePath();X.fill()}};if(sh==='beam'){bar(280,w+Math.sin(t*.8)*w*.12,[[1,al(c,.35)],[.65,al(c,.8)],[.3,c2]]);glow(w*1.8,c)}else if(sh==='thin'){bar(160,w*.5,[[1,al(c,.6)],[.4,'#fff']]);glow(w*1.2,c)}else if(sh==='sphere'){const r=w+Math.sin(t*.3)*5;glow(r,c);X.strokeStyle=al(c2,.6);X.lineWidth=3;for(let i=0;i<5;i++){const a=t*.15+i*1.26;X.beginPath();X.moveTo(x+Math.cos(a)*r*1.5,y+Math.sin(a)*r*1.5);X.lineTo(x+Math.cos(a)*r*.7,y+Math.sin(a)*r*.7);X.stroke()}}else if(sh==='sword'){X.fillStyle=al(c,.45);X.fillRect(Math.min(x,x-d*90),y-12,90,24);X.fillStyle='#fff';X.beginPath();X.moveTo(x,y);X.lineTo(x-d*90,y-5);X.lineTo(x-d*90,y+5);X.fill();glow(26,c)}else if(sh==='spiral'){bar(220,w*.5,[[1,al(c,.3)],[.35,'#fff']]);X.lineWidth=3;for(const ph of[0,3.14]){X.strokeStyle=al(ph?c2:c,.9);X.beginPath();for(let i=0;i<=22;i++){const xx=x-d*i*10,yy=y+Math.sin(i*.8+t*.7+ph)*w*.9;i?X.lineTo(xx,yy):X.moveTo(xx,yy)}X.stroke()}glow(w*1.4,c)}else if(sh==='wave'){X.lineWidth=6;for(let i=0;i<4;i++){X.strokeStyle=al(c,.8-i*.18);X.beginPath();X.arc(x-d*i*26,y,40+i*14,d>0?-1.1:Math.PI-1.1,d>0?1.1:Math.PI+1.1);X.stroke()}glow(30,c)}else if(sh==='dragonOld'){X.lineWidth=w*.6;X.strokeStyle=al(c,.7);X.beginPath();for(let i=0;i<=18;i++){const xx=x-d*i*9,yy=y+Math.sin(i*.6-t*.5)*20;i?X.lineTo(xx,yy):X.moveTo(xx,yy)}X.stroke();X.fillStyle='#fff';X.beginPath();X.ellipse(x,y,w*.8,w*.5,0,0,6.28);X.fill();glow(w*1.3,c)}else if(sh==='kamehameha'){bar(250,w*.9,[[1,al(c,.3)],[.6,al(c,.8)],[.28,'#fff']]);X.lineWidth=3;X.strokeStyle='rgba(255,255,255,.8)';for(let k=0;k<2;k++){X.beginPath();for(let i=0;i<=22;i++){const xx=x-d*i*11,yy=y+Math.sin(i*.55-t*.5+k*3.14)*w*.55;i?X.lineTo(xx,yy):X.moveTo(xx,yy)}X.stroke()}glow(w*1.9,c);X.fillStyle='#fff';X.beginPath();X.arc(x,y,w*.55,0,6.28);X.fill()}
else if(sh==='galick'){bar(260,w*.8,[[1,al(c,.35)],[.6,al(c,.85)],[.25,'#ffe8ff']]);X.strokeStyle='rgba(255,255,136,.9)';X.lineWidth=2;for(let k=-1;k<=1;k+=2){let xx=x,yy=y+k*w*.7;X.beginPath();X.moveTo(xx,yy);for(let i=0;i<10;i++){xx-=d*26;yy=y+k*w*.7+(Math.random()-.5)*14;X.lineTo(xx,yy)}X.stroke()}glow(w*1.6,c);X.fillStyle='rgba(255,255,255,.9)';X.beginPath();X.ellipse(x,y,w*.7,w*.45,0,0,6.28);X.fill()}
else if(sh==='bigbang'){X.fillStyle=al(c,.35);X.beginPath();X.moveTo(x,y-w*.6);X.lineTo(x-d*90,y);X.lineTo(x,y+w*.6);X.fill();glow(w*1.6,c);X.fillStyle='#fff';X.beginPath();X.arc(x,y,w*.5,0,6.28);X.fill();X.strokeStyle='rgba(255,255,255,.8)';X.lineWidth=2;for(let i=0;i<8;i++){const a=t*.3+i*.785;X.beginPath();X.moveTo(x+Math.cos(a)*w*.5,y+Math.sin(a)*w*.5);X.lineTo(x+Math.cos(a)*w*1.1,y+Math.sin(a)*w*1.1);X.stroke()}}
else if(sh==='dragon'){for(let i=18;i>=0;i--){const xx=x-d*i*9,yy=y+Math.sin(i*.6-t*.5)*20,r=w*.5*(1-i/24)+4;X.fillStyle=al(i%2?c:'#ffffff',.55+.4*(1-i/18));X.beginPath();X.arc(xx,yy,r,0,6.28);X.fill()}const hy=y+Math.sin(-t*.5)*20;X.fillStyle='#fff';X.beginPath();X.ellipse(x+d*6,hy,w*.7,w*.45,0,0,6.28);X.fill();X.fillStyle=al(c,.9);X.beginPath();X.moveTo(x+d*w*.6,hy-4);X.lineTo(x+d*w*1.1,hy-8);X.lineTo(x+d*w*.6,hy+2);X.fill();X.beginPath();X.moveTo(x+d*w*.6,hy+4);X.lineTo(x+d*w*1.05,hy+10);X.lineTo(x+d*w*.5,hy+8);X.fill();X.fillStyle='#d00';X.beginPath();X.arc(x+d*w*.1,hy-6,3,0,6.28);X.fill();glow(w*1.3,c)}
else if(sh==='flash'){bar(300,w*1.1+Math.sin(t*.9)*6,[[1,al(c,.3)],[.7,al(c,.8)],[.35,'#fff']]);X.strokeStyle='rgba(255,255,255,.7)';X.lineWidth=2;for(let i=0;i<8;i++){const a=t*.2+i*.785;X.beginPath();X.moveTo(x,y);X.lineTo(x+Math.cos(a)*w*2.2,y+Math.sin(a)*w*2.2);X.stroke()}glow(w*2.4,c)}
else if(sh==='fusion'){bar(300,w*.4,[[1,'#fff']]);X.lineWidth=11;for(const ph of[0,3.14]){X.strokeStyle=al(ph?c2:c,.85);X.beginPath();for(let i=0;i<=26;i++){const xx=x-d*i*11,yy=y+Math.sin(i*.5+t*.4+ph)*w*.55;i?X.lineTo(xx,yy):X.moveTo(xx,yy)}X.stroke()}glow(w*2,c)}
else if(sh==='beastk'){bar(290,w,[[1,al(c2,.4)],[.6,al(c2,.8)],[.3,'#fff']]);X.strokeStyle='#e8d0ff';X.lineWidth=2;for(let k=0;k<3;k++){let xx=x,yy=y;X.beginPath();X.moveTo(xx,yy);for(let i=0;i<12;i++){xx-=d*24;yy=y+(Math.random()-.5)*w*1.8;X.lineTo(xx,yy)}X.stroke()}glow(w*2,c2)}
else if(sh==='buster'){bar(260,w*.8,[[1,al(c,.4)],[.4,'#fff']]);X.fillStyle=al(c,.9);for(let i=0;i<8;i++)X.fillRect(x-d*(i*34+(t*10)%34)-8,y-w*.9,10,w*1.8);X.strokeStyle='#fff';X.lineWidth=3;X.beginPath();X.moveTo(x-w*1.6,y);X.lineTo(x+w*1.6,y);X.moveTo(x,y-w*1.6);X.lineTo(x,y+w*1.6);X.stroke();glow(w*1.8,c)}
else if(sh==='ringbeam'){bar(300,w,[[1,al(c,.35)],[.6,al(c,.85)],[.25,'#fff']]);X.lineWidth=3;X.strokeStyle=al(c2,.9);for(let i=0;i<7;i++){X.beginPath();X.ellipse(x-d*(i*40+(t*8)%40),y,7,w*1.1,0,0,6.28);X.stroke()}glow(w*2,c)}
else if(sh==='genki'){const r=w+Math.sin(t*.3)*6;glow(r*1.5,c);X.strokeStyle='rgba(255,255,255,.5)';X.lineWidth=2;for(let i=0;i<12;i++){const a=t*.1+i*.52;X.beginPath();X.moveTo(x+Math.cos(a)*r*.6,y+Math.sin(a)*r*.6);X.lineTo(x+Math.cos(a)*r*1.8,y+Math.sin(a)*r*1.8);X.stroke()}X.fillStyle='#fff';X.beginPath();X.arc(x,y,r*.55,0,6.28);X.fill();for(let i=0;i<8;i++){const a=-t*.12+i*.785;X.fillStyle=al(c,.9);X.beginPath();X.arc(x+Math.cos(a)*r*1.2,y+Math.sin(a)*r*1.2,5,0,6.28);X.fill()}}
else if(sh==='stardust'){for(let i=0;i<26;i++){const a=t*.15+i*.62,r=w*(.4+(i%6)*.16);X.fillStyle='hsl('+((i*28+t*9)%360)+',100%,65%)';X.save();X.translate(x+Math.cos(a)*r,y+Math.sin(a)*r);X.rotate(a);X.fillRect(-5,-1.5,10,3);X.fillRect(-1.5,-5,3,10);X.restore()}glow(w*1.2,'#ffffff')}
else if(sh==='meteor'){const tx=x-p.vx*7,ty=y-p.vy*7;X.fillStyle=al(c,.45);X.beginPath();X.moveTo(x,y-w*.6);X.lineTo(tx,ty);X.lineTo(x,y+w*.6);X.fill();X.fillStyle=al(c2,.5);X.beginPath();X.moveTo(x,y-w*.35);X.lineTo((tx+x)/2,(ty+y)/2);X.lineTo(x,y+w*.35);X.fill();X.fillStyle=al(c,.95);X.beginPath();for(let i=0;i<10;i++){const a=i*.628,rr=w*.62*(.8+.25*rnd(i+Math.floor(t/6)));X.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}X.fill();glow(w*1.6,c)}
else if(sh==='nova'){X.globalCompositeOperation='source-over';X.fillStyle='rgba(0,0,0,.35)';X.beginPath();X.ellipse(x,GY+8,w*.9,10,0,0,6.28);X.fill();X.globalCompositeOperation='lighter';glow(w*1.4,c);X.strokeStyle=al('#f33',.7);X.lineWidth=5;X.beginPath();X.arc(x,y,w*(1+Math.sin(t*.4)*.06),0,6.28);X.stroke();X.fillStyle='#fff';X.beginPath();X.arc(x,y,w*.5,0,6.28);X.fill()}
else if(sh==='planet'){const r=w;glow(r*1.5,c);X.save();X.beginPath();X.arc(x,y,r,0,6.28);X.clip();X.fillStyle=al(c,.9);X.fillRect(x-r,y-r,r*2,r*2);X.strokeStyle=al(c2,.55);X.lineWidth=8;for(let i=-2;i<=2;i++){X.beginPath();X.moveTo(x-r,y+i*r*.35+Math.sin(t*.1+i)*4);X.lineTo(x+r,y+i*r*.35-Math.sin(t*.1+i)*4);X.stroke()}X.restore();X.strokeStyle='rgba(255,255,255,.8)';X.lineWidth=4;X.beginPath();X.ellipse(x,y,r*1.7,r*.4,-.4,0,6.28);X.stroke()}
else if(sh==='hakai'){X.globalCompositeOperation='source-over';X.fillStyle='#0a0014';X.beginPath();X.arc(x,y,w*.8,0,6.28);X.fill();X.globalCompositeOperation='lighter';const r=w*.8;X.lineWidth=6;X.strokeStyle=al(c,.9);X.beginPath();X.arc(x,y,r,0,6.28);X.stroke();for(let i=0;i<3;i++){const rr=r+((t*3+i*20)%60);X.strokeStyle=al(c2,.6-(rr-r)/110);X.lineWidth=3;X.beginPath();X.arc(x,y,rr,0,6.28);X.stroke()}glow(r*1.8,c)}
else if(sh==='impact'){bar(170,w*.5,[[1,al(c,.5)],[.3,'#fff']]);for(let i=0;i<3;i++){const rr=((t*9+i*30)%90)+10;X.strokeStyle=al(c,1-rr/100);X.lineWidth=6;X.beginPath();X.arc(x,y,rr,0,6.28);X.stroke()}glow(w,c)}
else if(sh==='ghosts'){X.globalCompositeOperation='source-over';for(let k=0;k<3;k++){const gx=x-d*k*28,gy=y+(k-1)*38+Math.sin(t*.3+k)*8;X.fillStyle=al(c,.9);X.beginPath();X.arc(gx,gy,20,Math.PI,0);for(let i=0;i<=4;i++)X.lineTo(gx+20-i*10,gy+20+(i%2?-5:4));X.closePath();X.fill();X.strokeStyle='#406';X.lineWidth=2;X.stroke();X.fillStyle='#406';X.beginPath();X.arc(gx-7,gy-3,3,0,6.28);X.arc(gx+7,gy-3,3,0,6.28);X.fill();X.beginPath();X.ellipse(gx,gy+7,5,3,0,0,6.28);X.fill()}}
else if(sh==='cuts'){const w0=p.wait>0;X.lineWidth=w0?2:5;for(let i=0;i<7;i++){const a=rnd(i+Math.floor(t/3))*3.14,L=w*(w0?.8:1.8);X.strokeStyle=al(i%2?c:'#ffffff',w0?.4:.95);X.beginPath();X.moveTo(x-Math.cos(a)*L,y-Math.sin(a)*L);X.lineTo(x+Math.cos(a)*L,y+Math.sin(a)*L);X.stroke()}glow(w,c)}
else if(sh==='scythe'){for(let i=0;i<4;i++){X.strokeStyle=i?al(c,.5-i*.1):al(c,.95);X.lineWidth=i?10:16;X.beginPath();X.arc(x-d*(30+i*26),y,w,d>0?-1.2:Math.PI-1.2,d>0?1.2:Math.PI+1.2);X.stroke()}X.strokeStyle='#fff';X.lineWidth=4;X.beginPath();X.arc(x-d*30,y,w,d>0?-1.2:Math.PI-1.2,d>0?1.2:Math.PI+1.2);X.stroke();glow(w*.8,c)}
else if(sh==='rain'){for(let i=0;i<9;i++){const ox=(i-4)*w*.26,oy=-((i*53+t*14)%140);X.fillStyle=al(c,.45);X.fillRect(x+ox-4,y+oy-60,8,60);X.fillStyle=al(c,.95);X.beginPath();X.arc(x+ox,y+oy,13,0,6.28);X.fill();X.fillStyle='#fff';X.beginPath();X.arc(x+ox,y+oy,6,0,6.28);X.fill()}}
else if(sh==='fireball'){bar(190,w*.9,[[1,al('#ff4400',.4)],[.6,al(c,.75)],[.3,'#fff']]);glow(w*1.5,c);X.fillStyle='#fff';X.beginPath();X.arc(x,y,w*.45,0,6.28);X.fill();for(let i=0;i<6;i++){X.fillStyle=al(c,.8);X.fillRect(x-d*(40+i*30+(t*7)%30),y+(rnd(i+Math.floor(t/4))-.5)*w*1.4,8,8)}}
else if(sh==='volcano'){if(p.wait>0){X.strokeStyle=al(c,.7);X.lineWidth=3;X.beginPath();X.ellipse(x,GY+6,Math.max(4,w*(1-p.wait/40)),12,0,0,6.28);X.stroke()}else{for(let i=-2;i<=2;i++){const hh=130+Math.sin(t*.5+i)*30-Math.abs(i)*25,cx=x+i*w*.45,g=X.createLinearGradient(0,GY,0,GY-hh);g.addColorStop(0,al(c,.9));g.addColorStop(1,al('#ffffff',.3));X.fillStyle=g;X.beginPath();X.moveTo(cx-18,GY+6);X.lineTo(cx-8,GY-hh);X.lineTo(cx+8,GY-hh);X.lineTo(cx+18,GY+6);X.fill()}glow(w,c)}}
else if(sh==='rush'){for(let i=0;i<7;i++){X.fillStyle=al(i%2?c:'#ffffff',.8);X.beginPath();X.arc(x-d*i*9+(Math.random()-.5)*10,y+(Math.random()-.5)*46,6+Math.random()*5,0,6.28);X.fill()}glow(w,c)}else if(sh==='charge'){bar(120,w*.8,[[1,al(c,.4)],[.6,al(c,.9)],[.25,'#fff']]);glow(w*1.6,c)}else if(sh==='saucer'){X.save();X.translate(x,y);X.rotate(t*.5);X.fillStyle=al(c,.9);X.beginPath();X.ellipse(0,0,w,w*.28,0,0,6.28);X.fill();X.fillStyle='#fff';X.beginPath();X.ellipse(0,0,w*.7,w*.14,0,0,6.28);X.fill();X.restore();glow(w*1.2,c)}else if(sh==='multi'){for(let i=0;i<14;i++){const a=t*.2+i*.45,r=w*(.5+(i%5)*.12);X.fillStyle='hsl('+((i*40+t*8)%360)+',100%,65%)';X.beginPath();X.arc(x-d*i*8+Math.cos(a)*r*.4,y+Math.sin(a)*r,5,0,6.28);X.fill()}glow(w,c)}else{X.fillStyle=al(c,.4);X.beginPath();X.moveTo(x,y-w*.6);X.lineTo(x-d*70,y);X.lineTo(x,y+w*.6);X.fill();glow(w*1.3,c)}X.restore()}
// ---- PV max, Ultra Instinct, Ultra Ego, rage ----
function egoB(x){const T=[[0,0],[.1,.1],[.2,.2],[.3,.35],[.4,.5],[.5,.75],[.6,1]];if(x>=.6)return 1;for(let i=1;i<T.length;i++)if(x<T[i][0]){const a=T[i-1],b=T[i];return a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0])}return 1}
function applyForm(f,idx){const o=f.mhp||HPB;if(f.f$.ego&&!f.c.fm[idx].ego)f.eg=0;f.fm=idx;const nw=HPB*(f.c.hb||1)*f.f$.hm;if(f.hp>0)f.hp=Math.max(.5,f.hp*nw/o);if(f.dh!=null)f.dh*=nw/o;f.mhp=nw}
function extras(f,fo,lk){const e=lk.ex,sk=fo.sk;X.lineJoin='round';X.strokeStyle='#000';X.lineWidth=3;
if(e==='piccolo'){X.fillStyle='#f4f4f4';X.beginPath();X.ellipse(2,-106,14,9,0,Math.PI,0);X.fill();X.stroke();X.fillRect(-12,-108,28,5);for(const dx of[-1,1])L(2+dx*3,-111,2+dx*7,-126,2.5,sk);X.fillStyle=sk;X.beginPath();X.moveTo(-11,-100);X.lineTo(-24,-110);X.lineTo(-11,-93);X.fill();X.stroke()}
else if(e==='cell'){Pg([[-8,-108],[-12,-132],[2,-116],[11,-136],[12,-108]],'#2f7a2a',3);X.fillStyle='rgba(0,0,0,.35)';for(let i=0;i<4;i++){X.beginPath();X.arc(-4+i*5,-88+(i%2)*6,1.8,0,6.28);X.fill()}}
else if(e==='beerus'){Pg([[-9,-108],[-13,-132],[0,-111]],sk,3);Pg([[4,-111],[13,-132],[14,-106]],sk,3);X.fillStyle='#e9a';X.beginPath();X.moveTo(-8,-110);X.lineTo(-11,-124);X.lineTo(-2,-112);X.fill()}
else if(e==='jiren'){X.strokeStyle='#1a1a24';X.lineWidth=5;X.beginPath();X.moveTo(-2,-105);X.lineTo(7,-101);X.moveTo(8,-101);X.lineTo(16,-105);X.stroke()}
else if(e==='buu'){L(2,-112,-4,-128,4,sk);L(-4,-128,-18,-122,4,sk);X.fillStyle=sk;X.beginPath();X.arc(-19,-122,4,0,6.28);X.fill();X.stroke()}
else if(e==='cooler'){Pg([[4,-92],[15,-95],[15,-85],[4,-83]],'#5a3a8a',2)}
else if(e==='bardock'){X.fillStyle='#d33';X.fillRect(-12,-105,29,5);X.strokeStyle='#000';X.lineWidth=2;X.strokeRect(-12,-105,29,5);X.strokeStyle='#a33';X.lineWidth=2;X.beginPath();X.moveTo(10,-96);X.lineTo(14,-88);X.stroke()}
else if(e==='ginyu'){Pg([[-4,-108],[-12,-130],[2,-110]],'#e8e8f0',2);Pg([[6,-110],[18,-128],[12,-106]],'#e8e8f0',2)}
else if(e==='nappa'){X.fillStyle='#111';X.fillRect(4,-91,11,3)}
else if(e==='trunks'){L(-6,-86,-12,-98,5,'#6a3a1a');L(-12,-98,-28,-130,3,'#ddd')}}
function cinBg(){if(!(G.cin>0))return;G.cin--;X.fillStyle='rgba(0,0,10,'+Math.min(.6,G.cin/30*.6+.25)+')';X.fillRect(0,0,W,540);X.save();X.globalCompositeOperation='lighter';X.strokeStyle=al(G.cinc,.3);X.lineWidth=3;for(let i=0;i<(LOW?8:24);i++){const a=i*(LOW?.785:.2618)+G.tick*.012;X.beginPath();X.moveTo(G.cinx,GY-60);X.lineTo(G.cinx+Math.cos(a)*900,GY-60+Math.sin(a)*900);X.stroke()}X.restore()}
function dmgPop(v,d){
 const a=G.a,T=G.tr||(G.tr={last:0,pct:0,tot:0,cmb:0,hits:0,max:0}),bl=v.st==='b',fr=d/(v.mhp||HPB);
 T.last=Math.round(d);T.pct=fr*100;T.tot+=d;T.hits++;T.max=Math.max(T.max,d);
 if(!bl){if(a.combo<=1)T.cmb=0;T.cmb+=d}
 (G.dn||(G.dn=[])).push({x:v.x+(Math.random()-.5)*40,y:v.y-115,t:68,s:Math.round(d),total:Math.round(T.cmb),c:bl?'#9ab':fr>.2?'#ff6a2a':fr>.08?'#ffe14a':'#ffffff',z:Math.min(22,fr*160),bl});
 if(G.dn.length>14)G.dn.shift()
}
function dnDraw(){
 if(cfg.mode!=='train'&&cfg.mode!=='story')return;
 X.save();X.textAlign='center';X.lineJoin='round';
 for(const q of G.dn||[]){
  q.y-=.75;q.t--;X.globalAlpha=Math.min(1,q.t/18);
  X.font='900 '+(20+q.z)+'px sans-serif';X.lineWidth=5;X.strokeStyle='#000';
  const tx=(q.bl?'BLOQUÉ ':'')+q.s;X.strokeText(tx,q.x,q.y);X.fillStyle=q.c;X.fillText(tx,q.x,q.y);
  if(!q.bl&&q.total>q.s){X.font='bold 14px sans-serif';X.lineWidth=4;X.strokeStyle='#000';X.strokeText('COMBO · '+q.total,q.x,q.y+20);X.fillStyle='#8ff';X.fillText('COMBO · '+q.total,q.x,q.y+20)}
 }
 X.globalAlpha=1;if(G.dn)G.dn=G.dn.filter(q=>q.t>0);
 if(cfg.mode==='train'){
  const T=G.tr||{last:0,pct:0,tot:0,cmb:0,hits:0,max:0},x=W-262,y=124;
  X.fillStyle='rgba(0,0,10,.6)';X.fillRect(x,y,250,112);X.strokeStyle='#8cf';X.lineWidth=1.5;X.strokeRect(x,y,250,112);X.textAlign='left';X.font='bold 13px sans-serif';X.fillStyle='#8cf';X.fillText('DÉGÂTS INFLIGÉS',x+10,y+18);X.font='13px sans-serif';X.fillStyle='#fff';X.fillText('Dernier coup : '+T.last+' ('+T.pct.toFixed(1)+' %)',x+10,y+38);X.fillText('Combo : '+(G.a.combo>1?G.a.combo:0)+' coups · '+Math.round(T.cmb)+' dégâts',x+10,y+56);X.fillText('Meilleur coup : '+Math.round(T.max),x+10,y+74);X.fillText('Total : '+Math.round(T.tot)+' ('+T.hits+' coups)',x+10,y+92);X.font='11px sans-serif';X.fillStyle='#9ab';X.fillText('Retour arrière : remettre à zéro',x+10,y+107)
 }
 X.restore()
}
// ---- v14 : moteur d'animation par poses (idle, marche, course, saut, chute, atterrissage, coups, blocage...) ----
let LN=[];
Object.assign(LOOK.Goku,{an:{stance:'open',bounce:3}});Object.assign(LOOK.Vegeta,{an:{stance:'cross',bounce:1}});
function dust(x,n){for(let i=0;i<n&&!LOW;i++)fx.push({x:x+(Math.random()-.5)*16,y:GY-2,vx:(Math.random()-.5)*3,vy:-Math.random()*1.6,l:16+Math.random()*10,col:'#cdbfa0',r:2+Math.random()*3})}
function anim(f){const g=f.y>=GY-1;if(f.wasAir&&g){f.land=9;dust(f.x,7)}f.wasAir=!g;if(f.land>0)f.land--;
if(f.st==='r'&&g){f.run=(f.run|0)+1;f.ph=(f.ph||0)+Math.abs(f.vx)*.085*(Math.sign(f.vx*f.face)||1);if(f.run>22&&f.run%7==0)dust(f.x-f.face*10,3);if(f.run>22&&f.run%3==0&&LN.length<30)LN.push({x:f.x-f.face*24,y:f.y-20-Math.random()*70,l:30+Math.random()*30,t:8,f:f.face})}else f.run=0;
if(f.st==='d'&&f.t%2==0&&LN.length<30)LN.push({x:f.x-f.face*20,y:f.y-30-Math.random()*60,l:40+Math.random()*40,t:10,f:f.face});
if(G.over){if(f.hp<=0)f.dt=(f.dt|0)+1;else f.vt=(f.vt|0)+1}}
function lnDraw(){X.save();X.fillStyle='#fff';for(const q of LN){q.t--;X.globalAlpha=Math.max(0,q.t/10*.6);X.fillRect(q.x,q.y,-q.f*q.l,2)}X.restore();LN=LN.filter(q=>q.t>0)}
function attPose(f,P){const a=f.atk&&f.atk.s!=null?f.atk:null,t=f.t,at=f.at,av=f.av|0;
if((at==='li'||at==='he')&&a){const s0=a.s,s1=a.s+a.a,ac=t<s0?'a':t<=s1?'x':'r';
if(at==='li'){if(av==0){P.hf=ac==='a'?[10,-70]:ac==='x'?[50,-74]:[28,-72];P.ln=ac==='x'?7:-3;P.fl=ac==='x'?[22,0,6]:[14,0,5]}
else if(av==1){P.hr=ac==='a'?[-4,-66]:ac==='x'?[52,-72]:[14,-64];P.ln=ac==='x'?9:-4;P.rl=ac==='x'?[-8,0,3]:[-14,0,2]}
else{P.fl=ac==='a'?[14,-30,12]:ac==='x'?[46,-58,2]:[16,-10,8];P.ln=ac==='x'?-6:2;P.hf=[10,-80];P.hr=[-20,-70]}}
else{if(av==0){P.hf=ac==='a'?[2,-112]:ac==='x'?[44,-50]:[26,-70];P.hr=ac==='a'?[-4,-108]:ac==='x'?[38,-46]:[12,-64];P.ln=ac==='x'?10:-6;P.sy=ac==='x'?.92:1.03}
else if(av==1){P.fl=ac==='a'?[-6,-4,8]:ac==='x'?[52,-62,2]:[16,-8,8];P.ln=ac==='x'?-8:-4;P.hf=[0,-84];P.hr=[-24,-76];P.rot=ac==='x'?-f.face*.08:0}
else{P.hf=ac==='a'?[18,-48]:ac==='x'?[42,-112]:[26,-70];P.hy=ac==='a'?-30:-38;P.ln=ac==='x'?6:-2}}
return}
const m=f.mv||{},PZ={kamehameha:'kame',galick:'galick',flash:'flash',bigbang:'bigbang',dragon:'lunge'},pz=m.pz||PZ[m.sh]||(m.up?'up':m.dash?'lunge':/beam|fusion|ringbeam|beastk|buster|scythe|spiral/.test(m.sh||'')?'kame':'thrust'),ff=m.f||14,x=t>=ff;
if(pz==='up'){P.hf=[12,-126];P.hr=[-8,-122];P.fl=[16,0,6];P.rl=[-16,0,6];P.jx=Math.sin(t*1.4)*1.2;return}
if(pz==='kame'){P.hf=x?[40,-66]:[-2,-58];P.hr=x?[34,-66]:[-8,-56];P.ln=x?6:-6;P.hy=-31;P.fl=[22,0,8];P.rl=[-20,0,8]}
else if(pz==='galick'){P.hf=x?[42,-72]:[-6,-78];P.hr=x?[34,-68]:[-12,-74];P.ln=x?8:-8;P.fl=[20,0,6];P.rl=[-22,0,6];P.jx=x?0:Math.sin(t*1.6)}
else if(pz==='flash'){P.hf=[34,-72];P.hr=[28,-60];P.ln=x?4:0;P.hy=-32;P.fl=[24,0,8];P.rl=[-22,0,8];P.jx=Math.sin(t*2.2)*(x?1.8:.8)}
else if(pz==='bigbang'){P.hf=x?[46,-78]:[30,-80];P.hr=x?[10,-60]:[14,-66];P.ln=x?6:-2}
else if(pz==='lunge'){const y=t>=ff-4;P.hf=y?[52,-66]:[0,-60];P.hr=y?[-18,-66]:[-12,-56];P.ln=y?12:-8;P.hy=-31;P.fl=y?[30,0,8]:[12,0,6];P.rl=y?[-24,0,3]:[-16,0,4];P.sx=y?1.1:1}
else{P.hf=x?[44,-70]:[14,-50];P.hr=x?[38,-72]:[8,-48];P.ln=x?5:-5;P.fl=[18,0,6];P.rl=[-18,0,6]}
if(at==='ul'&&t<ff*.5){P.hf=[30,-92];P.hr=[-30,-92];P.jx=Math.sin(t*1.6)*1.5;P.hy=-31}}
function pose(f){const t=G.tick,st=f.st,an=f.c.lk.an||{},s=f.face,air=f.y<GY-6,bob=Math.sin(t*.1)*(an.bounce==null?2:an.bounce),ph=f.ph||0;
const P={hf:[26,-72+bob],hr:[12,-64+bob],fl:[14,0,5],rl:[-14,0,2],ln:0,sx:1,sy:1+Math.sin(t*.12)*.012,rot:0,hy:-38,jx:0,al:1};
if(an.stance==='cross'){P.hf=[20,-66+bob*.3];P.hr=[15,-61+bob*.3];P.fl=[16,0,4];P.rl=[-16,0,3]}else if(an.stance==='open'){P.hf=[28,-66+bob];P.hr=[8,-58+bob];P.fl=[17,0,8];P.rl=[-15,0,7];P.hy=-36}
if(st==='r'&&!air){const run=f.run>22,S=run?15:8;P.hf=[24+Math.sin(ph+3.14)*(run?12:5),-70+Math.cos(ph)*(run?5:2)];P.hr=[10+Math.sin(ph)*(run?12:5),-62-Math.cos(ph)*(run?5:2)];P.fl=[Math.sin(ph)*S,-Math.max(0,Math.cos(ph))*(run?10:6),5];P.rl=[-Math.sin(ph)*S,-Math.max(0,-Math.cos(ph))*(run?10:6),5];if(run){P.ln=8;P.sy=.97}}
if(air){const k=Math.max(0,Math.min(1,(-f.vy+4)/12)),mx=(a,b)=>[a[0]+(b[0]-a[0])*k,a[1]+(b[1]-a[1])*k,(a[2]||0)+((b[2]||0)-(a[2]||0))*k];P.fl=mx([8,-10,6],[10,-24,12]);P.rl=mx([-8,-4,2],[-8,-14,-4]);P.hf=mx([24,-88],[26,-98]);P.hr=mx([-16,-84],[8,-88]);P.ln=2-4*k}
if(!air&&f.land>0&&(st==='i'||st==='r')){P.hy=-30;P.sy=.9;P.fl=[16,0,10];P.rl=[-14,0,8];P.hf=[22,-62];P.hr=[8,-56]}
if(f.cr&&!air&&(st==='i'||st==='b')){P.hy=-28;P.sy=.85;P.fl=[18,0,10];P.rl=[-12,0,8]}
if(f.chg&&(st==='i'||st==='r')){P.hf=[10,-52];P.hr=[-8,-52];P.fl=[20,0,8];P.rl=[-20,0,8];P.hy=-30;P.sy=.92;P.jx=Math.sin(t*1.7)*1.2}
if(st==='b'){P.hf=[20,-90];P.hr=[14,-82];P.sx=.94;P.fl=[16,0,6];P.rl=[-16,0,4]}
if(st==='h'){const k=Math.min(1,Math.abs(f.vx)/10);P.hf=[-8-k*10,-62+k*12];P.hr=[-24-k*8,-54+k*14];P.ln=-5-k*5;P.sx=.92;P.sy=1.06;P.rot=-s*(.14+.35*k);P.fl=[6,-6*k,2];P.rl=[-16,-14*k,2]}
if(st==='d'){P.ln=-8;P.hf=[-14,-72];P.hr=[-24,-66];P.fl=[-4,0,4];P.rl=[-22,0,3];P.al=.55+.35*Math.sin(t*1.5);P.sx=1.08}
if(st==='t'){const u=f.t<20;P.hy=u?-28:-38;P.sy=u?.88:1.02;P.hf=u?[8,-48]:[34,-54];P.hr=u?[-8,-48]:[-34,-54];P.fl=[22,0,6];P.rl=[-22,0,6];P.jx=Math.sin(t*2)*(u?2:1)}
if(st==='a')attPose(f,P);
if(G.over){if(f.hp<=0){const k=Math.min(1,(f.dt|0)/20);P.rot=-s*1.35*(1-(1-k)*(1-k));P.hf=[18,-30];P.hr=[-16,-34]}else if(G.win===f){P.hf=[16,-122];P.hr=[-8,-70];P.fl=[16,0,5];P.rl=[-14,0,2];P.sy=1.02}}
return P}
function smoothPose(f,T){const c=f.pz;if(!c||G.tick-(f.pzt||0)>3){f.pz=JSON.parse(JSON.stringify(T));f.pzt=G.tick;return f.pz}f.pzt=G.tick;const k=f.st==='a'?.55:f.st==='h'?.7:.3;for(const q in T){const a=c[q],b=T[q];if(Array.isArray(b)){for(let i=0;i<b.length;i++)a[i]=(a[i]||0)+(b[i]-(a[i]||0))*k}else c[q]=a+(b-a)*k}return c}
function sep(a,b){if(a.y>=GY-1&&b.y>=GY-1){const gap=48,dist=Math.abs(b.x-a.x);if(dist<gap){const mid=(a.x+b.x)/2,dir=a.x<=b.x?1:-1;a.x=Math.max(30,Math.min(W-30,mid-dir*gap/2));b.x=Math.max(30,Math.min(W-30,mid+dir*gap/2))}}}
function sfxMv(m){const u=m.d>40;switch(m.sh){case'kamehameha':snd(300,.5,'sine',.07);snd(600,.4,'triangle',.04);break;case'galick':snd(130,.6,'sawtooth',.07);break;case'flash':snd(90,.9,'sawtooth',.1);snd(400,.5,'square',.04);break;case'bigbang':snd(700,.25,'square',.06);break;case'dragon':snd(140,.5,'sawtooth',.08);snd(90,.7,'sawtooth',.06);break;case'genki':snd(500,.8,'sine',.06);snd(750,.6,'triangle',.04);break;default:snd(u?220:500,.5,u?'sawtooth':'sine',.08)}}
function ghostAt(v){(G.gh||(G.gh=[])).push({x:v.x,t:18,o:v});if(G.gh.length>12)G.gh.shift()}
function ghosts(){for(const g of G.gh||[]){if(--g.t<=0)continue;const q=Object.create(g.o);q.x=g.x;X.globalAlpha=g.t/18*.5;body(q);X.globalAlpha=1}G.gh=(G.gh||[]).filter(g=>g.t>0)}
function tags(f){const y=f.y-f.f$.sc*(f.c.lk.sc||1)*150-14;let s='',c='#fff',v=-1;if(f.f$.ui){s='ÉSQUIVES '+(f.ui|0)+'/5';c='#cde'}else if(f.f$.ego){v=egoB((f.eg||0)/(f.mhp||HPB));s='EGO +'+Math.round(v*100)+'% · '+Math.round(f.eg||0)+' PV encaissés';c='#c070ff'}else if(f.c.n==='Broly'&&(f.rage||0)>1){v=f.rage/100;s='RAGE '+Math.round(f.rage)+'%';c='#7f5'}if(!s)return;X.save();X.textAlign='center';X.font='bold 13px sans-serif';X.lineWidth=3;X.strokeStyle='#000';X.strokeText(s,f.x,y);X.fillStyle=c;X.fillText(s,f.x,y);if(v>=0){X.fillStyle='#000a';X.fillRect(f.x-35,y+4,70,6);X.fillStyle=c;X.fillRect(f.x-35,y+4,70*Math.min(1,v),6)}else for(let i=0;i<5;i++){X.fillStyle=i<(f.ui|0)?c:'#0008';X.beginPath();X.arc(f.x-24+i*12,y+9,4,0,6.28);X.fill()}X.restore()}
// ---- v7 : PV 10 000, fiches de stats, Kaioken ----
const HPB=10000;
const STT={
Goku:{fo:38,vi:42,in:36,du:38,en:40,ed:42,ki:44,te:44,d:'Polyvalent, endurant, grande marge de progression via le Kaioken et ses transformations.'},
Vegeta:{fo:40,vi:40,in:38,du:38,en:41,ed:39,ki:40,te:42,d:'Fier guerrier offensif. Ultra Égo : plus il encaisse, plus il frappe.'},
Gogeta:{fo:64,vi:68,in:60,du:58,en:66,ed:62,ki:65,te:68,d:'Fusion redoutable : très rapide et offensive dès sa forme de base.'},
Vegetto:{fo:63,vi:66,in:62,du:60,en:65,ed:63,ki:66,te:68,d:'Fusion polyvalente : techniques précises, mobilité et défense solide.'},
Broly:{fo:54,vi:36,in:26,du:56,en:50,ed:58,ki:48,te:30,d:'Force brute colossale, lent mais très résistant. Sa rage le rend incontrôlable.'},
'Gohan':{fo:38,vi:39,in:44,du:37,en:42,ed:38,ki:41,te:42,d:'Potentiel latent immense : modéré en base, explosif une fois transformé.'},
Freezer:{fo:44,vi:48,in:50,du:42,en:50,ed:40,ki:48,te:50,d:'Tyran cruel et précis, spécialiste des attaques énergétiques à distance.'}
};
Object.assign(STT,{
Trunks:{fo:36,vi:40,in:42,du:34,en:38,ed:37,ki:38,te:44,d:'Épéiste précis et vif : portée de coups étendue et enchaînements rapides.'},
Piccolo:{fo:34,vi:35,in:52,du:38,en:40,ed:42,ki:38,te:46,d:'Stratège expérimenté : techniques précises et régénération passive.'},
Cell:{fo:48,vi:45,in:48,du:52,en:50,ed:52,ki:50,te:46,d:'Bio-androïde parfait : très résistant, rayons puissants et grande endurance.'},
Beerus:{fo:62,vi:61,in:58,du:59,en:63,ed:60,ki:62,te:60,d:'Dieu de la destruction : puissant et mobile, mais exige une bonne gestion de ses ressources.'},
Jiren:{fo:72,vi:68,in:56,du:76,en:72,ed:75,ki:70,te:64,d:'La muraille de l’Univers 11 : défense quasi impénétrable et frappe lourde.'}
});
HS.trunks=[[-14,-92],[-20,-98],[-28,-84],[-18,-96],[-16,-112],[-6,-110],[0,-124],[8,-110],[18,-114],[16,-98],[15,-92],[8,-102],[0,-99],[-8,-102]];
Object.assign(STT,{'Android 13':{fo:53,vi:52,in:36,du:50,en:48,ed:44,ki:45,te:38,d:'Combattant artificiel robuste, spécialisé dans les attaques directes.'},Tapion:{fo:42,vi:44,in:58,du:42,en:48,ed:55,ki:50,te:60,d:'Héros épéiste, précis et équilibré, qui scelle les menaces.'}});
Object.assign(STT,{
Gotenks:{fo:44,vi:50,in:30,du:40,en:48,ed:42,ki:46,te:42,d:'Fusion imprévisible : rapide, attaques fantômes, mais manque de discipline.'},
'Majin Buu':{fo:48,vi:40,in:24,du:58,en:50,ed:60,ki:52,te:32,d:'Créature magique : régénère ses PV et encaisse d’énormes dégâts.'},
Hit:{fo:54,vi:66,in:64,du:48,en:52,ed:54,ki:52,te:70,d:'Assassin légendaire : saut temporel et précision chirurgicale.'},
'Goku Black':{fo:46,vi:48,in:50,du:44,en:50,ed:46,ki:48,te:50,d:'Divinité dans un corps de Saiyan : lame divine et puissance croissante.'},
Cooler:{fo:46,vi:48,in:48,du:46,en:50,ed:44,ki:48,te:48,d:'Frère de Freezer : froid, méthodique et redoutable à distance.'},
Bardock:{fo:32,vi:34,in:32,du:32,en:32,ed:36,ki:32,te:34,d:'Guerrier Saiyan acharné : plus dangereux lorsque sa vie baisse.'}
});
HS.hit=[[-14,-92],[-20,-100],[-24,-86],[-30,-60],[-18,-84],[-16,-106],[-4,-112],[8,-108],[14,-100],[15,-92],[8,-100],[0,-102],[-8,-100]];
const RG={Piccolo:.002,'Majin Buu':.003};
Object.assign(STT,{
Raditz:{fo:26,vi:28,in:24,du:25,en:26,ed:26,ki:25,te:26,d:'Guerrier Saiyan impitoyable, frère aîné de Goku.'},
Nappa:{fo:34,vi:22,in:20,du:36,en:32,ed:34,ki:28,te:22,d:'Colosse Saiyan : très résistant et brutal, mais lent.'}
});
Object.assign(STT,{
Ginyu:{fo:35,vi:36,in:36,du:35,en:36,ed:35,ki:34,te:38,d:'Capitaine des forces spéciales : technique solide et style déroutant.'}
});
Object.assign(STT,{
 'Baby Vegeta':{fo:50,vi:48,in:48,du:50,en:52,ed:48,ki:50,te:48,d:'Parasite Tsuful : puissance élevée et attaques énergétiques dévastatrices.'},
 'Omega Shenron':{fo:64,vi:56,in:54,du:66,en:66,ed:64,ki:64,te:56,d:'Dragon maléfique ultime : puissance colossale et très haute résistance.'},
 Cumber:{fo:60,vi:44,in:30,du:60,en:56,ed:58,ki:52,te:40,d:'Saiyan maléfique : force brute écrasante et pression constante.'},
 Hearts:{fo:52,vi:54,in:60,du:48,en:58,ed:52,ki:56,te:60,d:'Combattant tactique : contrôle de la gravité et précision remarquable.'},
 Glorio:{fo:32,vi:42,in:44,du:30,en:38,ed:36,ki:40,te:44,d:'Guerrier du royaume démoniaque : agile, rapide et adepte de magie.'},
 Gomah:{fo:30,vi:28,in:46,du:32,en:40,ed:34,ki:42,te:38,d:'Roi démoniaque : compense sa force modérée par la magie et la ruse.'},
 Tamagami:{fo:46,vi:42,in:46,du:52,en:46,ed:50,ki:44,te:46,d:'Gardien des Dragon Balls : défense solide et maîtrise martiale.'},
 'Xeno Goku':{fo:46,vi:48,in:46,du:46,en:48,ed:48,ki:48,te:48,d:'Patrouilleur du temps : plus expérimenté et puissant que sa version standard.'},
 Shallot:{fo:36,vi:38,in:34,du:36,en:38,ed:38,ki:38,te:36,d:'Saiyan ancien : style équilibré avec un fort potentiel de transformation.'}
});
// ---- Extension du roster : combattants majeurs manquants ----
const EXTRA=[
 {n:'Zarbon',hair:'#39a879',gi:'#285e9a',aura:'#8fd',tf:'Forme monstre',fm:[['Base','#39a879','#8fd'],['Forme monstre','#286b53','#9f8']],st:[46,44,52,46,48,44,46,52,'Officier de Freezer, technique et puissant après transformation.'],mv:[['Elegant Blaster',20,26,14,30,'beam','#8fd'],['Wild Dash',24,30,10,32,'rush','#8fd'],['Monster Crusher',54,94,36,74,'nova','#9f8']]},
 {n:'Dodoria',hair:'#d47b9d',gi:'#a94b70',aura:'#f9a',tf:'Puissance maximale',fm:[['Base','#d47b9d','#f9a'],['Puissance maximale','#d47b9d','#fff']],st:[48,30,28,54,40,48,38,30,'Soldat brutal de Freezer, lent mais solide.'],mv:[['Crusher Ball',20,26,14,30,'sphere','#f9a'],['Headbutt',26,32,8,34,'rush','#f9a'],['Dodoria Launcher',52,90,34,70,'nova','#fff']]},
 {n:'King Cold',hair:'#b8d5e8',gi:'#4b5b88',aura:'#9cf',tf:'Forme royale',fm:[['Base','#b8d5e8','#9cf'],['Forme royale','#dceeff','#fff']],st:[52,34,58,58,54,52,56,50,'Roi de l’empire, robuste et méthodique.'],mv:[['Cold Beam',20,26,14,30,'thin','#9cf'],['Royal Impact',26,34,12,36,'rush','#9cf'],['Imperial Nova',58,98,40,80,'nova','#fff']]},
 {n:'Videl',hair:'#33252b',gi:'#e8e5e0',aura:'#f9b',tf:'Potentiel éveillé',fm:[['Base','#33252b','#f9b'],['Potentiel éveillé','#33252b','#fff']],st:[24,50,46,26,24,44,24,52,'Artiste martiale rapide, technique et sans attaque énergétique majeure.'],mv:[['Eagle Kick',18,24,8,26,'rush','#f9b'],['Videl Rush',22,28,10,30,'rush','#f9b'],['Justice Combination',48,84,30,66,'rush','#fff']]},

 {n:'Android 17',hair:'#6b4b2e',gi:'#172b42',aura:'#8cf',tf:'Énergie infinie',fm:[['Base','#6b4b2e','#8cf'],['Énergie infinie','#6b4b2e','#bff']],st:[44,48,50,46,50,65,68,48,'Combattant endurant, réserve d’énergie exceptionnelle.'],mv:[['Barrier Blast',19,25,14,30,'wave','#8cf'],['Accel Driver',25,32,10,34,'rush','#8cf'],['Super Electric Strike',55,95,36,72,'beam','#bff']]},
 {n:'Android 18',hair:'#d6c49a',gi:'#d7d7df',aura:'#f9d',tf:'Énergie infinie',fm:[['Base','#d6c49a','#f9d'],['Puissance libérée','#d6c49a','#fff']],st:[42,50,50,43,48,65,68,50,'Très mobile, précise et infatigable.'],mv:[['Destructo Disc',20,26,12,28,'sword','#f9d'],['Accel Dance',24,30,8,32,'rush','#f9d'],['Infinity Bullet',54,92,34,70,'multi','#fff']]},
 {n:'Krillin',hair:'#1c1c1c',gi:'#e85b24',aura:'#fd8',tf:'Potentiel libéré',fm:[['Base','#1c1c1c','#fd8'],['Potentiel libéré','#1c1c1c','#fff']],st:[18,26,38,18,24,25,24,40,'Technique et ruse : dangereux malgré une force moindre.'],mv:[['Kienzan',18,24,10,26,'sword','#fd8'],['Taiyoken',15,20,8,24,'wave','#fff'],['Kamehameha',48,86,30,66,'beam','#fd8']]},
 {n:'Yamcha',hair:'#8a4a24',gi:'#d8d8e8',aura:'#8cf',tf:'Puissance maximale',fm:[['Base','#8a4a24','#8cf'],['Puissance maximale','#8a4a24','#fd8']],st:[17,25,24,16,20,22,20,28,'Combattant rapide, spécialiste des enchaînements.'],mv:[['Rogafufuken',18,24,8,26,'rush','#8cf'],['Sokidan',22,28,16,32,'sphere','#8cf'],['Spirit Ball',48,86,32,68,'sphere','#fff']]},
 {n:'Tenshinhan',hair:'#171717',gi:'#273b66',aura:'#fd8',tf:'Quatre corps',fm:[['Base','#171717','#fd8'],['Puissance maximale','#171717','#fff']],st:[22,25,36,22,26,28,25,42,'Arts martiaux, contrôle et techniques exigeantes.'],mv:[['Dodonpa',19,25,12,28,'thin','#fd8'],['Kikoho',30,38,22,42,'beam','#fd8'],['Shin Kikoho',54,94,38,76,'pillar','#fff']]},
 {n:'Muten Roshi',hair:'#e8e8e8',gi:'#e8e8e8',aura:'#9cf',tf:'Max Power',fm:[['Normal','#e8e8e8','#9cf'],['Max Power','#e8e8e8','#fff']],st:[16,18,48,16,26,22,26,50,'Maître expérimenté, technique et maîtrise du ki.'],mv:[['Kamehameha',20,26,14,30,'beam','#9cf'],['Drunken Fist',22,28,8,30,'rush','#9cf'],['Max Power Kamehameha',52,92,34,72,'beam','#fff']]},
 {n:'Android 16',hair:'#e0a65c',gi:'#315b48',aura:'#9f8',tf:'Mode combat',fm:[['Base','#e0a65c','#9f8'],['Mode combat','#e0a65c','#cfa']],st:[46,30,34,54,44,60,55,36,'Très résistant, lent et puissant au corps-à-corps.'],mv:[['Rocket Punch',22,28,12,30,'rush','#9f8'],['Hell Flash',28,36,20,40,'beam','#9f8'],['Final Impact',56,96,40,78,'beam','#cfa']]},
 {n:'Kefla',hair:'#24202b',gi:'#3a9b64',aura:'#5f8',tf:'Super Saiyan 2',fm:[['Base','#24202b','#5f8'],['Super Saiyan','#3fba72','#5f8'],['Super Saiyan 2','#4fe18b','#cfa']],st:[56,62,44,50,60,56,58,52,'Fusion explosive : très rapide et offensive.'],mv:[['Gigantic Burst',22,28,16,32,'sphere','#5f8'],['Ray Blast',28,36,18,38,'beam','#8f8'],['Gigantic Explosion',60,100,42,82,'nova','#cfa']]},
 {n:'Caulifla',hair:'#1b1b22',gi:'#5c2d55',aura:'#f8c',tf:'Super Saiyan 2',fm:[['Base','#1b1b22','#f8c'],['Super Saiyan','#fd2','#fd8'],['Super Saiyan 2','#fd2','#fff']],st:[35,44,32,32,38,38,36,38,'Saiyan très rapide, agressive et adaptable.'],mv:[['Crush Cannon',18,24,12,28,'ball','#f8c'],['Energy Fist',24,30,8,30,'rush','#f8c'],['Limit Breaker',52,90,32,70,'beam','#fff']]},
 {n:'Kale',hair:'#17251b',gi:'#267a4a',aura:'#5f5',tf:'Super Saiyan Berserk',fm:[['Base','#17251b','#5f5'],['Super Saiyan','#fd2','#8f8'],['Berserk','#8f5','#5f5']],st:[44,30,26,44,40,46,38,28,'Puissance énorme, résistance élevée, vitesse réduite.'],mv:[['Gigantic Press',24,30,12,34,'rush','#5f5'],['Blaster Cannon',28,36,18,40,'beam','#8f8'],['Gigantic Burst',62,100,42,84,'nova','#cfc']]},
 {n:'Cabba',hair:'#30251e',gi:'#315a48',aura:'#fd8',tf:'Super Saiyan 2',fm:[['Base','#30251e','#fd8'],['Super Saiyan','#fd2','#fd8'],['Super Saiyan 2','#fd2','#fff']],st:[33,38,36,32,35,36,34,38,'Saiyan équilibré, rapide et discipliné.'],mv:[['Galick Cannon',18,24,14,28,'beam','#fd8'],['Energy Blast',22,28,16,32,'ball','#fd8'],['Final Impact',50,88,32,68,'beam','#fff']]},
 {n:'Toppo',hair:'#29232b',gi:'#9a2630',aura:'#b9f',tf:'Dieu de la destruction',fm:[['Base','#29232b','#b9f'],['Dieu de la destruction','#29232b','#b9f']],st:[62,48,54,68,64,64,62,54,'Défenseur massif, devient redoutable en mode divin.'],mv:[['Justice Flash',20,26,14,30,'beam','#b9f'],['Justice Crusher',26,34,12,36,'rush','#b9f'],['Hakai Burst',60,100,44,82,'nova','#e9f']]},
 {n:'Dyspo',hair:'#d9d4ca',gi:'#6e293b',aura:'#f8a',tf:'Super Maximum Light Speed',fm:[['Base','#d9d4ca','#f8a'],['Vitesse maximale','#d9d4ca','#fff']],st:[42,72,44,40,44,52,44,50,'Vitesse extrême, mais endurance défensive moyenne.'],mv:[['Circle Flash',18,24,10,26,'wave','#f8a'],['Light Bullet',22,28,12,30,'rush','#f8a'],['Super Maximum Light Speed',50,88,30,68,'rush','#fff']]},
 {n:'Zamasu fusionné',hair:'#1b1b22',gi:'#367b62',aura:'#8f8',tf:'Corps immortel',fm:[['Base','#1b1b22','#8f8'],['Corps immortel','#1b1b22','#cfc']],st:[64,56,64,68,68,66,68,64,'Fusion divine, très résistant et puissant.'],mv:[['Divine Wrath',22,28,16,32,'beam','#8f8'],['Holy Wrath',28,36,20,40,'sphere','#8f8'],['Light of Justice',62,100,46,86,'nova','#cfc']]},
 {n:'Dabura',hair:'#17131c',gi:'#742d3d',aura:'#c6f',tf:'Roi des démons',fm:[['Base','#17131c','#c6f'],['Magie démoniaque','#17131c','#f8c']],st:[42,40,48,42,46,42,46,48,'Magie, pétrification et attaques techniques.'],mv:[['Evil Impulse',18,24,14,28,'beam','#c6f'],['Stone Spit',22,28,16,32,'wave','#c6f'],['Demon Blade',52,92,34,72,'sword','#f8c']]},
 {n:'Janemba',hair:'#6b2020',gi:'#7a263b',aura:'#f6a',tf:'Super Janemba',fm:[['Base','#6b2020','#f6a'],['Super Janemba','#a22b40','#f6a']],st:[54,56,42,54,56,52,54,54,'Démon dimensionnel, rapide et imprévisible.'],mv:[['Dimension Sword',22,28,10,30,'sword','#f6a'],['Hell Gate',28,36,18,38,'wave','#f6a'],['Dimensional Collapse',60,100,42,82,'nova','#fff']]},
 {n:'Moro',hair:'#8b8172',gi:'#45566b',aura:'#8cf',tf:'Jeunesse absorbée',fm:[['Base','#8b8172','#8cf'],['Énergie absorbée','#8b8172','#8cf'],['Jeunesse absorbée','#333','#bff']],st:[56,46,68,58,66,60,68,64,'Magie et absorption d’énergie, polyvalent mais dangereux.'],mv:[['Energy Drain',20,26,16,30,'sphere','#8cf'],['Planetary Devourer',30,38,22,42,'wave','#8cf'],['Life Absorption',62,100,48,88,'nova','#bff']]},
 {n:'Granolah',hair:'#b8c4d4',gi:'#496d83',aura:'#9cf',tf:'Œil éveillé',fm:[['Base','#b8c4d4','#9cf'],['Œil éveillé','#b8c4d4','#fff']],st:[54,58,60,44,54,48,56,66,'Tireur d’élite : précision et vitesse exceptionnelles.'],mv:[['Precision Shot',20,26,12,28,'thin','#9cf'],['Vital Point Attack',26,34,10,36,'rush','#9cf'],['Ultimate Shot',58,98,36,78,'beam','#fff']]},
 {n:'Uub',hair:'#171717',gi:'#513b27',aura:'#f96',tf:'Énergie de Majin Buu',fm:[['Base','#171717','#f96'],['Énergie éveillée','#171717','#f96']],st:[34,38,34,34,40,38,38,36,'Combattant équilibré, grand potentiel latent.'],mv:[['Energy Blast',18,24,14,28,'ball','#f96'],['Power Rush',24,30,10,32,'rush','#f96'],['Majin Spirit Burst',52,90,34,70,'beam','#fff']]},
 {n:'Pan',hair:'#5a3020',gi:'#d94b32',aura:'#f9a',tf:'Potentiel éveillé',fm:[['Base','#5a3020','#f9a'],['Potentiel éveillé','#5a3020','#fff']],st:[22,36,30,22,26,30,26,34,'Petite combattante très mobile et technique.'],mv:[['Quick Rush',16,22,8,24,'rush','#f9a'],['Energy Ball',20,26,12,28,'ball','#f9a'],['Maiden Blast',44,82,28,62,'beam','#fff']]},
 {n:'Android 21',hair:'#a85d58',gi:'#e8e2d9',aura:'#f8a',tf:'Forme Majin',fm:[['Scientifique','#a85d58','#f8a'],['Forme Majin','#f4a','#f8a']],st:[46,46,62,44,54,48,56,56,'Génie scientifique, absorbe et adapte son énergie.'],mv:[['Energy Field',20,26,16,30,'wave','#f8a'],['Hungry Beam',26,34,18,38,'beam','#f8a'],['Majin Kamehameha',58,98,40,80,'beam','#fff']]},
 {n:'Pikkon',hair:'#b8c8a0',gi:'#3e805d',aura:'#9f8',tf:'Flamme du démon',fm:[['Base','#b8c8a0','#9f8'],['Flamme du démon','#b8c8a0','#fff']],st:[42,44,46,42,44,44,44,48,'Guerrier expérimenté, techniques et mobilité équilibrées.'],mv:[['Thunder Flash',20,26,14,30,'beam','#9f8'],['Hyper Tornado',24,32,12,34,'rush','#9f8'],['Flame of Justice',54,94,36,74,'nova','#fff']]},
 {n:'Gamma 1',hair:'#e8e8ee',gi:'#d82c32',aura:'#f66',tf:'Héros androïde',fm:[['Base','#e8e8ee','#f66']],st:[52,48,58,55,52,62,56,58,'Androïde héroïque créé par le Ruban Rouge, discipliné et précis.'],mv:[['Gamma Blaster',20,26,14,30,'beam','#f66'],['Justice Impact',25,32,12,36,'rush','#f66'],['Gamma Burst Flash',56,94,38,76,'nova','#fff']]},
 {n:'Gamma 2',hair:'#e7e7ef',gi:'#3467d8',aura:'#69c8ff',tf:'Héros androïde',fm:[['Base','#e7e7ef','#69c8ff']],st:[48,58,52,48,56,58,60,54,'Androïde héroïque très mobile, prêt à se sacrifier pour protéger les autres.'],mv:[['Gamma Kick',18,24,8,28,'rush','#69c8ff'],['Gamma Blaster',22,28,14,32,'beam','#69c8ff'],['Heroic Sacrifice',58,98,42,82,'nova','#fff']]},
 {n:'Hirudegarn',hair:'#422a36',gi:'#34222e',aura:'#f65',tf:'Forme colossale',fm:[['Forme scellée','#422a36','#f65'],['Hirudegarn colossal','#2a1823','#f33']],st:[78,34,38,82,62,44,54,32,'Monstre gigantesque libéré de son sceau, lent mais redoutable.'],mv:[['Flamme démoniaque',22,28,18,34,'beam','#f65'],['Frappe colossale',30,38,10,40,'rush','#f65'],['Ravage dimensionnel',62,102,42,86,'nova','#fff']]}
];
for(const e of EXTRA){
 // Réutilise la fiche déjà créée dans characters.js au lieu d'ajouter un doublon.
 let c=CH.find(x=>x.n===e.n);
 if(!c){c={n:e.n,hair:e.hair,gi:e.gi,aura:e.aura,sp:5,pw:1,tf:e.tf,tH:e.hair,tA:e.aura,sn:e.mv[0][0],un:e.mv[2][0]};CH.push(c)}
 else Object.assign(c,{hair:c.hair||e.hair,gi:c.gi||e.gi,aura:c.aura||e.aura,sp:Number(c.sp)||5,pw:Number(c.pw)||1,tf:c.tf||e.tf,tH:c.tH||e.hair,tA:c.tA||e.aura,sn:c.sn||e.mv[0][0],un:c.un||e.mv[2][0]});
 FM[e.n]=e.fm.map((f,i)=>fm(f[0],f[1],f[2],i?{eye:'#fff',el:true}:{}));
 LOOK[e.n]={top:e.gi,und:'#20202a',pa:e.gi,sash:e.aura,bt:'#222',gl:e.gi,mus:1,hs:'goku',pc:e.aura};
 STT[e.n]={fo:e.st[0],vi:e.st[1],in:e.st[2],du:e.st[3],en:e.st[4],ed:e.st[5],ki:e.st[6],te:e.st[7],d:e.st[8]};
 PM[e.n]=1;TW[e.n]={pw:1,hm:1,res:1,sp:1,kr:1};
 MVS[e.n]=e.mv.map((m,i)=>mv(m[0],m[1],m[2],m[3],m[4],m[5],m[6],'#fff',i===2?62:30,i===2?12:14,i===2?80:70,i===2?240:120));
}
Object.assign(FS,{'Énergie infinie':[1.5,.15,0],'Puissance libérée':[2,.2,0],'Potentiel libéré':[2,.2,0],'Puissance maximale':[2,.2,0],'Max Power':[2.2,.2,0],'Mode combat':[1.4,.15,0],'Super Saiyan':[1.5,.1,0],'Super Saiyan 2':[2,.15,0],'Super Saiyan Berserk':[3,.25,1200],'Super Maximum Light Speed':[1.4,.25,0],'Dieu de la destruction':[4.5,.3,1200],'Corps immortel':[3,.3,1200],'Magie démoniaque':[2.5,.2,0],'Super Janemba':[3,.25,1200],'Énergie absorbée':[3,.25,1200],'Jeunesse absorbée':[4,.3,1200],'Œil éveillé':[2.5,.2,0],'Énergie de Majin Buu':[2.5,.2,0],'Potentiel éveillé':[1.8,.15,0],'Forme Majin':[2.5,.25,1200],'Flamme du démon':[2,.2,0]});
Object.assign(HR,{'Énergie infinie':[1.3,.2],'Puissance libérée':[1.25,.18],'Potentiel libéré':[1.2,.15],'Puissance maximale':[1.2,.15],'Max Power':[1.3,.2],'Mode combat':[1.4,.25],'Super Saiyan':[1.5,.2],'Super Saiyan 2':[1.7,.25],'Super Saiyan Berserk':[1.5,.3],'Super Maximum Light Speed':[1.9,.35],'Dieu de la destruction':[1.7,.3],'Corps immortel':[1.8,.35],'Magie démoniaque':[1.5,.2],'Super Janemba':[1.8,.3],'Énergie absorbée':[1.8,.3],'Jeunesse absorbée':[2,.35],'Œil éveillé':[1.5,.25],'Énergie de Majin Buu':[1.5,.25],'Potentiel éveillé':[1.3,.2],'Forme Majin':[1.8,.3],'Flamme du démon':[1.5,.25]});
for(const c of CH){
 const t=STT[c.n]||(STT[c.n]={});
 for(const k of ['fo','vi','in','du','en','ed','ki','te']){
  const value=Number(t[k]??c.st?.[k]??75);
  t[k]=Math.max(10,Math.min(100,Number.isFinite(value)?Math.round(value):75));
 }
 if(!t.d)t.d=c.st?.d||'Profil de combat : '+c.n;
}
for(const e of EXTRA){const c=CH.find(x=>x.n===e.n),tw=TW[c.n];c.fm=FM[c.n].map((x,i)=>{const q=FS[x.n]||[1+i*.5,.1,0],h=HR[x.n]||[1,0];return Object.assign(x,{pw:1+(q[0]-1)*tw.pw,kr:Math.min(.5,q[1]*tw.kr),dur:q[2],sp:1+.045*i*tw.sp,hm:1+(h[0]-1)*tw.hm,res:Math.min(.5,h[1]*tw.res)})});c.lk=LOOK[c.n];c.lk.pm=PM[c.n];}
CH.forEach(c=>{
 const raw=STT[c.n]||{},previous=c.st||{},t=c.st=Object.assign({},previous,raw);
 for(const k of ['fo','vi','in','du','en','ed','ki','te']){
  const value=Number(raw[k]??previous[k]??75);
  t[k]=Math.round(44+((Number.isFinite(value)?value:75)-44)*.68);
 }
  // Vitesse (vi) : vitesse de déplacement, esquive et rapidité des attaques
  c.sp=+(2.6+t.vi*.036).toFixed(2);
  c.atkSpd=+(0.88+(t.vi/100)*0.36).toFixed(3);
  c.dodgeBonus=Math.max(0,Math.round((t.vi-20)/14));
  // Force (fo) : dégâts des coups physiques (échelle réduite pour combats plus longs)
  c.lk.pm=+(0.42+(t.fo/100)*0.55).toFixed(3);
  c.pw=(c.pw||1)*(0.48+(t.fo/100)*0.52);
  // Durabilité (du) : PV max et résistance aux dégâts
  c.hb=+(0.92+Math.max(0,Math.min(1,(t.du-25)/45))*0.20).toFixed(3);
  c.br=Math.max(0,Math.min(0.45,(t.du-10)/160));
  // Énergie (en) : puissance des attaques spéciales
  c.enMult=+(0.45+(t.en/100)*0.55).toFixed(3);
  // Intelligence (in) : stratégie, fenêtre de contre et réduction coût Ki
  c.parryBonus=Math.max(0,Math.round((t.in-15)/14));
  c.kiCostMult=+(1.10-(t.in/100)*0.24).toFixed(3);
  // Endurance (ed) : enchaînement d'actions (réduction cooldowns dash/esquive + drain Kaioken)
  c.cdMult=+(1.22-(t.ed/100)*0.45).toFixed(3);
  // Ki (ki) : réserve et récupération d'énergie
  c.kiRegenMult=+(0.75+(t.ki/100)*0.75).toFixed(3);
  // Technique (te) : précision, bonus de combos et stun
  c.techComboMult=+(1+(t.te/100)*0.22).toFixed(3);
  c.techStunBonus=Math.max(0,Math.round((t.te-20)/12));
});
const KK=[{x:1,d:1.15,s:1.1,dr:2,t:40,o:.02},{x:2,d:1.3,s:1.2,dr:4,t:30,o:.04},{x:5,d:1.6,s:1.35,dr:7,t:20,o:.07},{x:10,d:2,s:1.5,dr:12,t:12,o:.1},{x:20,d:2.6,s:1.7,dr:20,t:6,o:.15}],KKN=x=>x>1?'Kaioken x'+x:'Kaioken';
function endKK(f,ov){const k=KK[(f.kk||1)-1];f.kk=0;f.kt=0;if(ov){f.hp=Math.max(1,f.hp-(f.mhp||HPB)*k.o);f.st='h';f.t=0;f.stun=45;f.ki=Math.max(0,f.ki-10);spark(f.x,f.y-60,'#f33',20,8);G.ann={t:60,s:'SURCHARGE !',c:'#f55'}}}
function kaio(f,c){if(f.c.n!=='Goku'||f.nokk)return;if(c.kkP&&f.st!=='t'&&f.st!=='h'&&!f.f$.ui){const nx=(f.kk|0)+1;if(nx>5)endKK(f,0);else if(f.ki>=10){f.ki-=10;f.kk=nx;f.kt=Math.round(KK[nx-1].t*60*f.c.st.ed/95);spark(f.x,f.y-60,'#f33',16,8);ring(f.x,f.y-60,'#f44',90);snd(180,.3,'sawtooth',.08);G.ann={t:60,s:KKN(KK[nx-1].x).toUpperCase()+' !',c:'#f55'}}}
if(f.kk){const k=KK[f.kk-1];if(f.f$.ui){f.kk=0;return}const divine=['Super Saiyan God','Super Saiyan Blue','Blue Evolution','Ultra Instinct','Ultra Instinct maîtrisé','Ultra Ego','Super Saiyan Rosé','Godslayer','Destruction','Beast'].includes(f.f$.n);f.ki=Math.max(0,f.ki-k.dr/60*95/f.c.st.ed*(divine?.78:1));if(f.kt<k.t*54&&Math.random()<k.o*.004){endKK(f,1);return}if(--f.kt<=0||f.ki<=0)endKK(f,1)}}
function stOf(c,fi,withRpg=false){const s=Object.assign({},c.st),f=c.fm[fi||0],b=Math.round(Math.log2(f.pw)*10);for(const k of['fo','en','du'])s[k]+=b;s.vi+=Math.round(b*.8);s.ed+=Math.round(b*.3);s.ki+=Math.round(f.kr*60);if(f.ui){s.in+=8;s.te+=8}if(withRpg){for(const k of['fo','vi','in','du','en','ed','ki','te'])s[k]+=skillStatBonus(k)}return s}
const SN=[['fo','Force'],['vi','Vitesse'],['in','Intelligence'],['du','Durabilité'],['en','Énergie'],['ed','Endurance'],['ki','Ki'],['te','Technique']];
function statPanel(chosenIndex=cfg.p1){
 const w=document.createElement('div');w.className='fighter-stats-live';w.style.cssText='width:100%;display:flex;flex-direction:column;align-items:center;gap:8px';
 const render=()=>{
  w.replaceChildren();
  const a=CH[chosenIndex]||CH[cfg.p1]||CH[0],forms=Array.isArray(a.fm)&&a.fm.length?a.fm:[{n:'Base',pw:1,kr:1}],fi=Math.max(0,Math.min(cfg.sf|0,forms.length-1));
  let stats={...(a.st||{})};try{stats=stOf(a,fi,true)||stats}catch(err){console.warn('Calcul des statistiques:',err)}
  const compare=!!cfg.cmp,other=CH[chosenIndex===cfg.p1?cfg.p2:cfg.p1]||a;let otherStats=other.st||{};
  if(compare){try{otherStats=stOf(other,0,true)||otherStats}catch(err){}}
  w.appendChild(row(forms.map((f,i)=>btn(f.n,()=>{cfg.sf=i;render()},fi===i,'font-size:12px;padding:5px 8px')).concat([btn('Comparer : '+(compare?'OUI':'NON'),()=>{cfg.cmp=!cfg.cmp;render()},compare,'font-size:12px;padding:5px 8px')])));
  const d=document.createElement('div');d.className='selection-section';d.style.cssText='width:100%;box-sizing:border-box;font-size:13px;text-align:left;padding:12px';
  let h='<div style="text-align:center;font-weight:800;margin:2px 0 10px">'+a.n+' — '+(forms[fi].n||'Base')+(compare?' <span style="color:#ffd36a"> vs '+other.n+'</span>':'')+'</div>';
  for(const [k,label] of SN){const value=Math.max(0,Math.round(Number(stats[k])||0)),v2=compare?Math.max(0,Math.round(Number(otherStats[k])||0)):0;h+='<div style="display:grid;grid-template-columns:96px minmax(40px,1fr) 38px;gap:7px;align-items:center;margin:8px 0"><span>'+label+'</span><div style="height:10px;background:#18243a;border-radius:8px;overflow:hidden;position:relative"><div style="height:100%;width:'+Math.min(100,value/1.5)+'%;background:linear-gradient(90deg,#16bde9,#a68aff);border-radius:8px"></div>'+(compare?'<div style="position:absolute;left:0;top:0;height:3px;width:'+Math.min(100,v2/1.5)+'%;background:#ffd36a"></div>':'')+'</div><b style="text-align:right">'+value+'</b></div>'}
  d.innerHTML=h;w.appendChild(d);
 };
 render();return w;
}